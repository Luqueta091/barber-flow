# Guia de Integração: Painel do Barbeiro

## 1. Visão Geral
**O que é:** O Painel do Barbeiro é uma interface web responsiva destinada aos profissionais (barbeiros) para gestão operacional diária.
**Objetivo:** Permitir a visualização rápida da agenda do dia, execução de ações de atendimento (check-in/falta), gerenciamento de bloqueios de horário (almoço, manutenção) e consulta de disponibilidade de slots em tempo real.

---

## 2. Seções da UI

### Sidebar (Navegação)
*   **Links:** Agenda, Bloqueios e Exceções, Disponibilidade, Notificações.
*   **Propósito:** Navegação principal entre as visões do sistema. Colapsável em mobile.

### Header
*   **Elementos:**
    *   **Saudação:** "Olá, Barbeiro".
    *   **Status:** Indicador visual (Online/Offline).
    *   **Seletor de Unidade:** Dropdown para alternar entre filiais (se aplicável).
    *   **Botão Sincronizar:** Ação manual para recarregar dados.

### Agenda do Dia
*   **Exibição:** Lista de cards contendo horário, nome do cliente, serviço, avatar e status.
*   **Ações:** Botões para "Marcar falta" e "Check-in" em agendamentos pendentes/confirmados.

### Bloqueios e Exceções
*   **Formulário:** Criação de novos bloqueios manuais.
*   **Lista:** Exibição dos bloqueios ativos no dia corrente com opção de remoção.

### Slots Disponíveis
*   **Grid:** Visualização de grade de horários (ex: 08:00 a 20:00).
*   **Estados:** Livre (branco/clicável), Bloqueado (cinza), Agendado (verde).

### Notificações
*   **Lista:** Feed cronológico de eventos (novos agendamentos, cancelamentos).
*   **Indicadores:** Ícone de tipo (sucesso, alerta, info) e estado de leitura (bolinha azul).

---

## 3. Atributos e IDs para Integração

Utilize estes seletores para vincular a lógica JS ao DOM:

### Inputs e Formulários
| ID | Tipo | Descrição |
| :--- | :--- | :--- |
| `unit-select` | Select | Dropdown para troca de unidade de atendimento. |
| `block-start` | Time Input | Horário de início do novo bloqueio. |
| `block-end` | Time Input | Horário de fim do novo bloqueio. |
| `block-reason` | Select | Motivo do bloqueio (Almoço, Férias, etc). |

### Data Attributes (Ações e Listas)

**Agendamentos (Cards):**
*   `data-appointment-id="{id}"`: Container do card do agendamento.
*   `data-action="mark-noshow"`: Botão de marcar falta.
*   `data-action="check-in"`: Botão de confirmar presença.

**Bloqueios (Lista e Form):**
*   `data-action="create-block"`: Botão de submit do formulário de bloqueio.
*   `data-block-id="{id}"`: Item da lista de bloqueios ativos.
*   `data-action="remove-block"`: Botão de lixeira para deletar bloqueio.

**Slots (Grid):**
*   `data-slot-id="{id}"`: Container do slot de tempo.
*   `data-slot-state="free|blocked|booked"`: Estado visual atual do slot.

---

## 4. Fluxos Esperados

### Gestão de Atendimento
1.  **Marcar Falta:** O usuário clica em `[data-action="mark-noshow"]`. O frontend deve confirmar a ação e disparar `PUT /agendamentos/{id}/falta`.
2.  **Check-in:** O usuário clica em `[data-action="check-in"]`. O status local muda visualmente e dispara atualização para o backend.

### Gestão de Bloqueios
1.  **Criar Bloqueio:** Preenchimento dos inputs `block-*` e clique em `create-block`.
    *   *Payload Base:* `{ start: "HH:mm", end: "HH:mm", reason: "string" }`.
    *   Backend valida conflitos e retorna o novo bloqueio criado.
2.  **Remover Bloqueio:** Clique em `remove-block` remove o item da lista e libera o horário na disponibilidade.

### Controle de Disponibilidade (Slots)
1.  **Bloquear Slot Rápido:** Clique em um slot com `data-slot-state="free"`.
    *   Ação: Chama endpoint `/slots/lock`.
2.  **Liberar Slot:** Clique em um slot com `data-slot-state="blocked"`.
    *   Ação: Chama endpoint `/slots/release`.

### Sincronização
1.  **Botão Sincronizar:** Ao clicar, exibir estado de *loading* e refazer os GETs de `/agendamentos`, `/availability` e `/notifications`.

---

## 5. Endpoints de Referência

Abaixo, sugestão de contratos de API para conectar ao frontend:

*   **GET** `/units/{id}/availability?date=YYYY-MM-DD`
    *   Retorna lista de slots e seus estados.
*   **POST** `/slots/lock`
    *   Bloqueia um horário específico.
*   **POST** `/slots/release`
    *   Libera um horário previamente bloqueado manualmente.
*   **GET** `/agendamentos?date=YYYY-MM-DD`
    *   Retorna a lista da agenda do dia.
*   **PUT** `/agendamentos/{id}/status`
    *   Atualiza para "compareceu" ou "falta".

---

## 6. Estados Vazios e Mensagens

*   **Agenda Vazia:**
    *   *Texto:* "Agenda livre hoje. Não há agendamentos marcados para esta data no momento."
    *   *Ação:* Link/Botão "Ver próximos dias".
*   **Lista de Bloqueios Vazia:**
    *   A lista simplesmente não renderiza itens, mantendo apenas o formulário visível.
*   **Notificações Vazias:**
    *   *Texto:* "Tudo tranquilo por aqui. Nenhuma notificação recente."

---

## 7. Design Tokens Resumidos

*   **Framework:** Tailwind CSS (via CDN).
*   **Tipografia:** "Sora" (Google Fonts).
    *   Pesos: 300 (Light), 400 (Regular), 600 (SemiBold).
*   **Paleta de Cores (Tailwind `slate` base):**
    *   Fundo App: `bg-slate-50`
    *   Card Background: `bg-white`
    *   Texto Principal: `text-slate-800`
    *   Texto Secundário: `text-slate-500`
    *   Ações Primárias: `text-slate-800` / `bg-slate-800` (Botões fortes).
    *   Destaques/Links: `text-primary-600` (Azul/Cyan - custom config).
    *   Sucesso/Agendado: `emerald-500`.
    *   Erro/Falta: `rose-600`.

---

## 8. Próximos Passos para Desenvolvimento

1.  **Mock Data Integration:** Substituir os arrays estáticos (`mockAppointments`, `mockBlocks`, etc.) por chamadas `fetch()` ou `axios`.
2.  **State Management:** Implementar contexto ou store (se usar React completo) para gerenciar o estado global de "Carregando" durante a sincronização.
3.  **Event Listeners:**
    *   Adicionar handlers para os botões de ação na Agenda.
    *   Implementar validação básica no formulário de bloqueio (ex: Início < Fim).
4.  **Websockets (Opcional):** Para atualizar a lista de "Notificações" e "Slots" em tempo real sem necessidade de recarregar a página.
