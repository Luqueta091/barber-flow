import React from 'react';
import { Notification } from '../types';
import { Bell, Scissors, AlertCircle, CheckCircle2 } from 'lucide-react';

const mockNotifications: Notification[] = [
  { id: 'notif-1', message: 'Novo agendamento: Ricardo M. (15:30)', timeAgo: '5 min atrás', isRead: false, type: 'success' },
  { id: 'notif-2', message: 'Cliente cancelou: João P. (10:00)', timeAgo: '1 hora atrás', isRead: true, type: 'alert' },
  { id: 'notif-3', message: 'Bloqueio de almoço sincronizado', timeAgo: '2 horas atrás', isRead: true, type: 'info' },
  { id: 'notif-4', message: 'Lembrete: Atualize sua disponibilidade para a próxima semana', timeAgo: '1 dia atrás', isRead: true, type: 'info' },
];

export const Notifications: React.FC = () => {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-semibold text-slate-800">Notificações</h2>
        <button className="text-xs font-medium text-primary-600 hover:text-primary-700">Marcar todas como lidas</button>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 shadow-sm divide-y divide-slate-100">
        {mockNotifications.map((notif) => (
          <div 
            key={notif.id} 
            className={`p-4 hover:bg-slate-50 transition-colors flex gap-4 ${!notif.isRead ? 'bg-primary-50/30' : ''}`}
          >
            <div className={`mt-1 min-w-[32px] w-8 h-8 rounded-full flex items-center justify-center border
              ${notif.type === 'success' ? 'bg-emerald-100 border-emerald-200 text-emerald-600' : ''}
              ${notif.type === 'alert' ? 'bg-rose-100 border-rose-200 text-rose-600' : ''}
              ${notif.type === 'info' ? 'bg-blue-100 border-blue-200 text-blue-600' : ''}
            `}>
              {notif.type === 'success' && <CheckCircle2 className="w-4 h-4" />}
              {notif.type === 'alert' && <AlertCircle className="w-4 h-4" />}
              {notif.type === 'info' && <Bell className="w-4 h-4" />}
            </div>

            <div className="flex-1">
              <p className={`text-sm ${!notif.isRead ? 'font-semibold text-slate-800' : 'text-slate-600'}`}>
                {notif.message}
              </p>
              <span className="text-xs text-slate-400 mt-1 block">{notif.timeAgo}</span>
            </div>

            {!notif.isRead && (
              <div className="flex items-center">
                <span className="w-2 h-2 bg-primary-500 rounded-full" title="Não lida"></span>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};