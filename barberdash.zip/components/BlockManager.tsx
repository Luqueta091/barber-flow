import React from 'react';
import { Block } from '../types';
import { Ban, Trash2, ShieldAlert } from 'lucide-react';

const mockBlocks: Block[] = [
  { id: 'blk-1', startTime: '12:00', endTime: '13:00', reason: 'Almoço' },
  { id: 'blk-2', startTime: '18:00', endTime: '19:00', reason: 'Manutenção Equipamento' },
];

export const BlockManager: React.FC = () => {
  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-xl font-semibold text-slate-800 mb-1">Bloqueios e Exceções</h2>
        <p className="text-sm text-slate-500">Gerencie seus horários indisponíveis manualmente.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Form Creation */}
        <div className="lg:col-span-1 bg-white p-6 rounded-xl border border-slate-200 shadow-sm h-fit">
          <h3 className="text-sm font-semibold text-slate-800 mb-4 flex items-center gap-2">
            <Ban className="w-4 h-4 text-slate-500" />
            Novo Bloqueio
          </h3>
          
          <form className="space-y-4" onSubmit={(e) => e.preventDefault()}>
            <div className="space-y-1">
              <label htmlFor="block-start" className="text-xs font-medium text-slate-600">Início</label>
              <input 
                type="time" 
                id="block-start" 
                name="block-start"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500/20 focus:border-primary-500 text-sm"
              />
            </div>
            
            <div className="space-y-1">
              <label htmlFor="block-end" className="text-xs font-medium text-slate-600">Fim</label>
              <input 
                type="time" 
                id="block-end" 
                name="block-end"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500/20 focus:border-primary-500 text-sm"
              />
            </div>

            <div className="space-y-1">
              <label htmlFor="block-reason" className="text-xs font-medium text-slate-600">Motivo</label>
              <select 
                id="block-reason" 
                name="block-reason"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500/20 focus:border-primary-500 text-sm text-slate-700"
              >
                <option value="lunch">Almoço</option>
                <option value="vacation">Férias</option>
                <option value="personal">Compromisso Pessoal</option>
                <option value="maintenance">Manutenção</option>
                <option value="other">Outro</option>
              </select>
            </div>

            <button 
              type="submit"
              data-action="create-block"
              className="w-full mt-2 bg-slate-800 hover:bg-slate-700 text-white text-sm font-medium py-2.5 rounded-lg transition-colors flex items-center justify-center gap-2"
            >
              Criar Bloqueio
            </button>
          </form>
        </div>

        {/* Active Blocks List */}
        <div className="lg:col-span-2 space-y-4">
          <h3 className="text-sm font-semibold text-slate-800 flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-slate-500" />
            Bloqueios Ativos (Hoje)
          </h3>

          <div className="space-y-3">
            {mockBlocks.map((block) => (
              <div 
                key={block.id}
                data-block-id={block.id}
                className="flex items-center justify-between p-4 bg-slate-50 border border-slate-200 rounded-lg hover:bg-white hover:shadow-sm transition-all"
              >
                <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-6">
                  <div className="flex items-center gap-2 text-sm font-bold text-slate-700 font-mono bg-slate-200 px-2 py-1 rounded">
                    <span>{block.startTime}</span>
                    <span className="text-slate-400">-</span>
                    <span>{block.endTime}</span>
                  </div>
                  <span className="text-sm font-medium text-slate-600">{block.reason}</span>
                </div>

                <button 
                  data-action="remove-block" 
                  data-block-id={block.id}
                  title="Remover bloqueio"
                  className="text-slate-400 hover:text-rose-600 p-2 hover:bg-rose-50 rounded-lg transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>

          <div className="mt-6 p-4 bg-blue-50 border border-blue-100 rounded-lg flex gap-3">
            <div className="text-blue-500 mt-0.5">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
              </svg>
            </div>
            <p className="text-xs text-blue-700 leading-relaxed">
              Bloqueios criados aqui são sincronizados imediatamente com o app do cliente. 
              Para bloqueios recorrentes (ex: todo almoço), contate o administrador da unidade.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};