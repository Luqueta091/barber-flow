import React from 'react';
import { ViewState } from '../types';
import { CalendarDays, Shield, Grid, Bell, LogOut, Scissors } from 'lucide-react';

interface SidebarProps {
  currentView: ViewState;
  onViewChange: (view: ViewState) => void;
  isOpen: boolean;
  onCloseMobile: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ currentView, onViewChange, isOpen, onCloseMobile }) => {
  const menuItems = [
    { label: ViewState.AGENDA, icon: CalendarDays },
    { label: ViewState.BLOCKS, icon: Shield },
    { label: ViewState.SLOTS, icon: Grid },
    { label: ViewState.NOTIFICATIONS, icon: Bell },
  ];

  return (
    <>
      {/* Mobile Overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-slate-900/50 z-20 md:hidden backdrop-blur-sm"
          onClick={onCloseMobile}
        ></div>
      )}

      {/* Sidebar Content */}
      <aside className={`
        fixed top-0 left-0 h-full w-64 bg-white border-r border-slate-200 z-30 transform transition-transform duration-300 ease-in-out
        md:translate-x-0 md:static flex flex-col justify-between
        ${isOpen ? 'translate-x-0' : '-translate-x-full'}
      `}>
        <div>
          {/* Brand */}
          <div className="h-16 flex items-center px-6 border-b border-slate-100">
             <div className="flex items-center gap-2 text-slate-800">
               <div className="w-8 h-8 bg-slate-900 text-white rounded-lg flex items-center justify-center">
                 <Scissors className="w-4 h-4" />
               </div>
               <span className="font-bold text-lg tracking-tight">BarberPro</span>
             </div>
          </div>

          {/* Navigation */}
          <nav className="p-4 space-y-1">
            {menuItems.map((item) => (
              <button
                key={item.label}
                onClick={() => {
                  onViewChange(item.label);
                  onCloseMobile();
                }}
                className={`
                  w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors
                  ${currentView === item.label 
                    ? 'bg-slate-800 text-white shadow-sm' 
                    : 'text-slate-500 hover:bg-slate-50 hover:text-slate-900'}
                `}
              >
                <item.icon className={`w-5 h-5 ${currentView === item.label ? 'text-slate-300' : 'text-slate-400'}`} />
                {item.label}
              </button>
            ))}
          </nav>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-100">
          <button className="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium text-slate-500 hover:bg-rose-50 hover:text-rose-600 transition-colors">
            <LogOut className="w-5 h-5" />
            Sair
          </button>
        </div>
      </aside>
    </>
  );
};