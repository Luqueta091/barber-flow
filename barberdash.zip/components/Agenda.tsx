import React from 'react';
import { Appointment } from '../types';
import { Calendar, Check, X, Clock, User } from 'lucide-react';

const mockAppointments: Appointment[] = [
  {
    id: 'appt-001',
    time: '09:00',
    clientName: 'Roberto Almeida',
    service: 'Corte Clássico',
    status: 'confirmed',
    avatar: 'https://picsum.photos/40/40?random=1'
  },
  {
    id: 'appt-002',
    time: '10:30',
    clientName: 'Carlos Dutra',
    service: 'Barba Terapia',
    status: 'pending',
    avatar: 'https://picsum.photos/40/40?random=2'
  },
  {
    id: 'appt-003',
    time: '14:00',
    clientName: 'Mario Santos',
    service: 'Corte + Barba',
    status: 'confirmed',
    avatar: 'https://picsum.photos/40/40?random=3'
  },
  {
    id: 'appt-004',
    time: '16:45',
    clientName: 'Sem Agendamento',
    service: '-',
    status: 'canceled',
  }
];

export const Agenda: React.FC = () => {
  const hasAppointments = mockAppointments.length > 0;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-semibold text-slate-800">Minha Agenda</h2>
          <p className="text-sm text-slate-500 flex items-center gap-1 mt-1">
            <Calendar className="w-4 h-4" />
            Hoje, {new Date().toLocaleDateString('pt-BR', { day: 'numeric', month: 'long' })}
          </p>
        </div>
        <div className="text-sm font-medium bg-emerald-50 text-emerald-700 px-3 py-1 rounded-full border border-emerald-100">
          3 Confirmados
        </div>
      </div>

      {/* Agenda List */}
      <div className="space-y-4">
        {hasAppointments ? (
          mockAppointments.map((appt) => (
            <div 
              key={appt.id}
              data-appointment-id={appt.id}
              className={`
                group relative bg-white border border-slate-200 rounded-xl p-4 shadow-sm hover:shadow-md transition-all duration-200
                ${appt.status === 'canceled' ? 'opacity-60 bg-slate-50' : ''}
              `}
            >
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                {/* Time & Client Info */}
                <div className="flex items-center gap-4">
                  <div className="flex flex-col items-center justify-center w-16 h-16 bg-slate-50 rounded-lg border border-slate-100">
                    <span className="text-lg font-bold text-slate-700">{appt.time}</span>
                  </div>
                  
                  <div>
                    <h3 className="font-semibold text-slate-800 flex items-center gap-2">
                      {appt.clientName}
                      {appt.status === 'pending' && <span className="w-2 h-2 rounded-full bg-amber-400" title="Pendente"></span>}
                    </h3>
                    <p className="text-sm text-slate-500 flex items-center gap-1">
                      <User className="w-3 h-3" />
                      {appt.service}
                    </p>
                  </div>
                </div>

                {/* Actions */}
                {appt.status !== 'canceled' && (
                  <div className="flex items-center gap-2 w-full sm:w-auto mt-2 sm:mt-0">
                    <button 
                      data-action="mark-noshow" 
                      data-appointment-id={appt.id}
                      className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-3 py-2 text-xs font-medium text-rose-600 bg-rose-50 hover:bg-rose-100 rounded-lg transition-colors"
                    >
                      <X className="w-4 h-4" />
                      Falta
                    </button>
                    <button 
                      data-action="check-in" 
                      data-appointment-id={appt.id}
                      className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-3 py-2 text-xs font-medium text-emerald-700 bg-emerald-50 hover:bg-emerald-100 rounded-lg transition-colors border border-emerald-100"
                    >
                      <Check className="w-4 h-4" />
                      Check-in
                    </button>
                  </div>
                )}
                
                {appt.status === 'canceled' && (
                  <span className="text-xs font-medium px-2 py-1 bg-slate-200 text-slate-500 rounded">Cancelado</span>
                )}
              </div>
            </div>
          ))
        ) : (
          /* Empty State / Skeleton */
          <div className="flex flex-col items-center justify-center py-12 text-center bg-white rounded-xl border border-dashed border-slate-300">
            <div className="w-12 h-12 bg-slate-100 rounded-full flex items-center justify-center mb-3">
              <Clock className="w-6 h-6 text-slate-400" />
            </div>
            <h3 className="text-lg font-medium text-slate-700">Agenda livre hoje</h3>
            <p className="text-slate-500 text-sm max-w-xs mx-auto mb-4">
              Não há agendamentos marcados para esta data no momento.
            </p>
            <button className="text-primary-600 text-sm font-medium hover:underline">
              Ver próximos dias
            </button>
          </div>
        )}
      </div>
    </div>
  );
};