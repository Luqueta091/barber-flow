import React from 'react';
import { Slot } from '../types';
import { Lock, Unlock, Clock } from 'lucide-react';

const generateSlots = (): Slot[] => {
  const slots: Slot[] = [];
  const startHour = 8;
  const endHour = 20;
  
  for (let h = startHour; h < endHour; h++) {
    ['00', '30'].forEach(m => {
      const time = `${h.toString().padStart(2, '0')}:${m}`;
      // Mock random states
      const rand = Math.random();
      let state: Slot['state'] = 'free';
      if (rand > 0.8) state = 'booked';
      else if (rand > 0.7) state = 'blocked';
      
      slots.push({ id: `slot-${h}-${m}`, time, state });
    });
  }
  return slots;
};

const mockSlots = generateSlots();

export const SlotAvailability: React.FC = () => {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-semibold text-slate-800">Disponibilidade de Slots</h2>
          <p className="text-sm text-slate-500">Visualização rápida de horários vagos.</p>
        </div>
        <div className="flex items-center gap-4 text-xs">
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded bg-white border border-slate-300"></span>
            <span className="text-slate-600">Livre</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded bg-slate-100 border border-slate-200"></span>
            <span className="text-slate-600">Bloqueado</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded bg-emerald-50 border border-emerald-200"></span>
            <span className="text-slate-600">Agendado</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-8 gap-3">
        {mockSlots.map((slot) => {
          const isFree = slot.state === 'free';
          const isBlocked = slot.state === 'blocked';
          const isBooked = slot.state === 'booked';
          
          return (
            <div
              key={slot.id}
              data-slot-id={slot.id}
              data-slot-state={slot.state}
              className={`
                relative group flex flex-col items-center justify-center p-3 rounded-xl border transition-all duration-200 cursor-pointer
                ${isFree ? 'bg-white border-slate-200 hover:border-primary-400 hover:shadow-sm' : ''}
                ${isBlocked ? 'bg-slate-100 border-slate-200 opacity-60' : ''}
                ${isBooked ? 'bg-emerald-50 border-emerald-200 cursor-default' : ''}
              `}
            >
              <span className={`text-sm font-semibold ${isBooked ? 'text-emerald-700' : 'text-slate-700'}`}>
                {slot.time}
              </span>
              
              {/* Overlay Action Icon (Visible on Hover for Free/Blocked) */}
              {!isBooked && (
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 bg-white/90 rounded-xl transition-opacity">
                   {isFree ? (
                     <Lock className="w-4 h-4 text-slate-500" />
                   ) : (
                     <Unlock className="w-4 h-4 text-primary-500" />
                   )}
                </div>
              )}
              
              {/* Status Icons for non-hover state */}
              <div className="mt-1">
                {isBooked && <div className="w-1.5 h-1.5 rounded-full bg-emerald-500"></div>}
                {isBlocked && <div className="w-1.5 h-1.5 rounded-full bg-slate-400"></div>}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};