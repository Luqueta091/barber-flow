import React, { useState } from 'react';
import { Sidebar } from './components/Sidebar';
import { Agenda } from './components/Agenda';
import { BlockManager } from './components/BlockManager';
import { SlotAvailability } from './components/SlotAvailability.tsx';
import { Notifications } from './components/Notifications';
import { ViewState } from './types';
import { Menu, RefreshCw, ChevronDown, Circle } from 'lucide-react';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<ViewState>(ViewState.AGENDA);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);

  const handleSync = () => {
    setIsSyncing(true);
    // Mock sync delay
    setTimeout(() => setIsSyncing(false), 1500);
  };

  const renderContent = () => {
    switch (currentView) {
      case ViewState.AGENDA: return <Agenda />;
      case ViewState.BLOCKS: return <BlockManager />;
      case ViewState.SLOTS: return <SlotAvailability />;
      case ViewState.NOTIFICATIONS: return <Notifications />;
      default: return <Agenda />;
    }
  };

  return (
    <div className="flex h-screen bg-slate-50 overflow-hidden">
      
      <Sidebar 
        currentView={currentView} 
        onViewChange={setCurrentView} 
        isOpen={isSidebarOpen}
        onCloseMobile={() => setIsSidebarOpen(false)}
      />

      <div className="flex-1 flex flex-col h-full overflow-hidden w-full relative">
        {/* Header */}
        <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-4 sm:px-8 z-10 shrink-0">
          
          <div className="flex items-center gap-3">
            <button 
              onClick={() => setIsSidebarOpen(true)}
              className="p-2 -ml-2 text-slate-500 hover:bg-slate-100 rounded-lg md:hidden"
            >
              <Menu className="w-5 h-5" />
            </button>
            
            <div className="flex flex-col">
              <h1 className="text-sm font-bold text-slate-800 hidden sm:block">Olá, Barbeiro</h1>
              <div className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                <span className="text-xs font-medium text-slate-500">Online</span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3 sm:gap-4">
            {/* Unit Selector */}
            <div className="relative group">
               <select 
                name="unit-select" 
                id="unit-select"
                className="appearance-none pl-3 pr-8 py-1.5 bg-slate-50 border border-slate-200 text-sm font-medium text-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-200 cursor-pointer hover:bg-slate-100 transition-colors"
               >
                 <option value="unit-1">Unidade Centro</option>
                 <option value="unit-2">Unidade Shopping</option>
               </select>
               <ChevronDown className="w-4 h-4 text-slate-400 absolute right-2 top-1/2 -translate-y-1/2 pointer-events-none" />
            </div>

            {/* Sync Button */}
            <button 
              onClick={handleSync}
              disabled={isSyncing}
              className="flex items-center gap-2 px-3 py-1.5 bg-white border border-slate-200 text-slate-600 hover:text-primary-600 hover:border-primary-200 rounded-lg text-sm font-medium transition-all shadow-sm active:scale-95 disabled:opacity-70"
            >
              <RefreshCw className={`w-4 h-4 ${isSyncing ? 'animate-spin text-primary-500' : ''}`} />
              <span className="hidden sm:inline">{isSyncing ? 'Sincronizando...' : 'Sincronizar'}</span>
            </button>
            
            <div className="w-8 h-8 rounded-full bg-slate-200 overflow-hidden border border-slate-300">
               <img src="https://picsum.photos/100/100" alt="Avatar" className="w-full h-full object-cover" />
            </div>
          </div>
        </header>

        {/* Main Content Area */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-8 scroll-smooth">
          <div className="max-w-5xl mx-auto animate-in fade-in slide-in-from-bottom-2 duration-300">
             {renderContent()}
          </div>
        </main>
      </div>
    </div>
  );
};

export default App;