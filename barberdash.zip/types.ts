export interface Appointment {
  id: string;
  time: string;
  clientName: string;
  service: string;
  status: 'confirmed' | 'pending' | 'completed' | 'canceled';
  avatar?: string;
}

export interface Block {
  id: string;
  startTime: string;
  endTime: string;
  reason: string;
}

export interface Slot {
  id: string;
  time: string;
  state: 'free' | 'blocked' | 'booked';
}

export interface Notification {
  id: string;
  message: string;
  timeAgo: string;
  isRead: boolean;
  type: 'info' | 'alert' | 'success';
}

export enum ViewState {
  AGENDA = 'Agenda',
  BLOCKS = 'Bloqueios',
  SLOTS = 'Disponibilidade',
  NOTIFICATIONS = 'Notificações'
}