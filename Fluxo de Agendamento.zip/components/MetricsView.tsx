import React from 'react';

export const MetricsView: React.FC = () => {
    return (
        <div className="animate-fade-in space-y-6">
            <h2 className="text-2xl font-bold text-slate-900">Métricas & Relatórios</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="bg-slate-900 text-white p-6 rounded-2xl shadow-lg">
                    <p className="text-slate-400 text-sm font-medium mb-1">Gasto Total (Ano)</p>
                    <p className="text-3xl font-bold">R$ 1.240,00</p>
                    <div className="mt-4 text-xs text-slate-400 flex items-center">
                        <span className="text-emerald-400 font-bold mr-1">+12%</span> vs ano anterior
                    </div>
                </div>
                
                <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
                    <p className="text-slate-500 text-sm font-medium mb-1">Total de Cortes</p>
                    <p className="text-3xl font-bold text-slate-900">18</p>
                </div>

                <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
                    <p className="text-slate-500 text-sm font-medium mb-1">Barbeiro Favorito</p>
                    <p className="text-xl font-bold text-slate-900 truncate">Carlos "Navalha"</p>
                </div>

                <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
                    <p className="text-slate-500 text-sm font-medium mb-1">Taxa de Cancelamento</p>
                    <p className="text-3xl font-bold text-emerald-600">0%</p>
                </div>
            </div>

            <div className="bg-white border border-slate-200 rounded-2xl p-8 text-center">
                 <div className="h-48 bg-slate-50 rounded-xl flex items-center justify-center border border-dashed border-slate-300">
                    <span className="text-slate-400 font-medium">Gráfico de Frequência (Placeholder D3.js)</span>
                 </div>
            </div>
        </div>
    )
}