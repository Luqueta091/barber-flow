import React from 'react';
import { ViewState } from '../types';
import { IconHome, IconCalendar, IconScissors, IconChart } from './Icons';

interface SidebarProps {
  currentView: ViewState;
  onChangeView: (view: ViewState) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ currentView, onChangeView }) => {
  const navItems: { id: ViewState; label: string; icon: React.FC<any> }[] = [
    { id: 'dashboard', label: 'Dashboard', icon: IconHome },
    { id: 'booking', label: 'Novo Agendamento', icon: IconScissors },
    { id: 'appointments', label: 'Meus Agendamentos', icon: IconCalendar },
  ];

  return (
    <aside className="w-full md:w-64 bg-white border-r border-slate-200 flex-shrink-0 flex flex-col h-full">
      <div className="p-6 border-b border-slate-100 flex items-center justify-center md:justify-start">
        <div className="w-8 h-8 bg-emerald-600 rounded-lg flex items-center justify-center mr-3">
            <IconScissors className="text-white w-5 h-5" />
        </div>
        <h1 className="text-xl font-bold text-slate-900 tracking-tight">BarberBook</h1>
      </div>

      <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => onChangeView(item.id)}
            className={`w-full flex items-center px-4 py-3 rounded-xl transition-all duration-200 group ${
              currentView === item.id
                ? 'bg-emerald-50 text-emerald-700 shadow-sm ring-1 ring-emerald-200'
                : 'text-slate-500 hover:bg-slate-50 hover:text-slate-900'
            }`}
          >
            <item.icon
              className={`w-5 h-5 mr-3 transition-colors ${
                currentView === item.id ? 'text-emerald-600' : 'text-slate-400 group-hover:text-slate-600'
              }`}
            />
            <span className="font-medium text-sm">{item.label}</span>
          </button>
        ))}
      </nav>

      <div className="p-4 border-t border-slate-100">
        <div className="flex items-center px-4 py-3 bg-slate-50 rounded-xl border border-slate-200">
          <div className="w-8 h-8 rounded-full bg-slate-300 flex-shrink-0 mr-3 overflow-hidden">
             <img src="https://picsum.photos/100/100?random=user" alt="User" className="w-full h-full object-cover" />
          </div>
          <div className="min-w-0">
            <p className="text-sm font-semibold text-slate-900 truncate">Roberto Almeida</p>
            <p className="text-xs text-slate-500 truncate">Cliente VIP</p>
          </div>
        </div>
      </div>
    </aside>
  );
};