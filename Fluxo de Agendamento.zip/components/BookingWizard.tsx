import React, { useState } from 'react';
import { Unit, Service, Barber } from '../types';
import { UNITS, SERVICES, BARBERS } from '../constants';
import { IconMapPin, IconClock, IconCheck, IconChevronRight } from './Icons';

interface BookingWizardProps {
  onComplete: () => void;
  onCancel: () => void;
}

export const BookingWizard: React.FC<BookingWizardProps> = ({ onComplete, onCancel }) => {
  const [step, setStep] = useState(1);
  const [selectedUnit, setSelectedUnit] = useState<Unit | null>(null);
  const [selectedService, setSelectedService] = useState<Service | null>(null);
  const [selectedBarber, setSelectedBarber] = useState<Barber | null>(null);
  const [selectedDate, setSelectedDate] = useState<string>('');
  const [selectedTime, setSelectedTime] = useState<string>('');

  // Mock slots
  const timeSlots = ['09:00', '10:00', '11:00', '14:00', '15:00', '16:00', '18:00'];

  const handleNext = () => {
    if (step < 5) setStep(step + 1);
  };

  const handleBack = () => {
    if (step > 1) setStep(step - 1);
  };

  const renderProgressBar = () => (
    <div className="mb-8">
      <div className="flex items-center justify-between relative">
        <div className="absolute left-0 top-1/2 transform -translate-y-1/2 w-full h-1 bg-slate-200 -z-10" />
        {[1, 2, 3, 4, 5].map((s) => (
          <div
            key={s}
            className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold border-2 transition-colors duration-300 ${
              s <= step
                ? 'bg-emerald-600 border-emerald-600 text-white'
                : 'bg-white border-slate-300 text-slate-400'
            }`}
          >
            {s < step ? <IconCheck className="w-4 h-4" /> : s}
          </div>
        ))}
      </div>
      <div className="flex justify-between text-xs text-slate-500 mt-2 font-medium">
        <span>Unidade</span>
        <span>Serviço</span>
        <span>Profissional</span>
        <span>Horário</span>
        <span>Confirmar</span>
      </div>
    </div>
  );

  return (
    <div className="max-w-4xl mx-auto h-full flex flex-col">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-slate-900">Novo Agendamento</h2>
        <p className="text-slate-500 mt-1">Siga os passos para reservar seu horário.</p>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 flex-1 flex flex-col overflow-hidden">
        <div className="p-8 flex-1 overflow-y-auto">
          {renderProgressBar()}

          {/* STEP 1: UNIT */}
          {step === 1 && (
            <div className="animate-fade-in">
              <h3 className="text-lg font-bold text-slate-900 mb-4">Escolha a Unidade</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {UNITS.map((unit) => (
                  <button
                    key={unit.id}
                    onClick={() => setSelectedUnit(unit)}
                    className={`text-left p-4 rounded-xl border-2 transition-all group hover:shadow-md ${
                      selectedUnit?.id === unit.id
                        ? 'border-emerald-500 bg-emerald-50/30'
                        : 'border-slate-100 hover:border-emerald-200'
                    }`}
                  >
                    <div className="h-32 rounded-lg bg-slate-200 overflow-hidden mb-4">
                      <img src={unit.image} alt={unit.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                    </div>
                    <div className="font-bold text-slate-900 text-lg">{unit.name}</div>
                    <div className="text-slate-500 text-sm flex items-center mt-1">
                        <IconMapPin className="w-4 h-4 mr-1" />
                        {unit.address}
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* STEP 2: SERVICE */}
          {step === 2 && (
            <div className="animate-fade-in">
              <h3 className="text-lg font-bold text-slate-900 mb-4">Selecione o Serviço</h3>
              <div className="space-y-3">
                {SERVICES.map((service) => (
                  <button
                    key={service.id}
                    onClick={() => setSelectedService(service)}
                    className={`w-full text-left p-5 rounded-xl border-2 transition-all flex justify-between items-center group hover:shadow-sm ${
                      selectedService?.id === service.id
                        ? 'border-emerald-500 bg-emerald-50/30'
                        : 'border-slate-100 hover:border-emerald-200'
                    }`}
                  >
                    <div>
                      <div className="font-bold text-slate-900 text-lg">{service.name}</div>
                      <div className="text-slate-500 text-sm mt-1">{service.description}</div>
                      <div className="text-xs font-semibold text-emerald-600 mt-2 bg-emerald-50 inline-block px-2 py-1 rounded-md">
                        {service.durationMin} minutos
                      </div>
                    </div>
                    <div className="text-xl font-bold text-slate-900">
                      R$ {service.price.toFixed(2)}
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* STEP 3: BARBER */}
          {step === 3 && (
            <div className="animate-fade-in">
              <h3 className="text-lg font-bold text-slate-900 mb-4">Escolha o Profissional</h3>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {BARBERS.map((barber) => (
                  <button
                    key={barber.id}
                    onClick={() => setSelectedBarber(barber)}
                    className={`text-center p-6 rounded-xl border-2 transition-all hover:shadow-md flex flex-col items-center justify-center h-full ${
                      selectedBarber?.id === barber.id
                        ? 'border-emerald-500 bg-emerald-50/30'
                        : 'border-slate-100 hover:border-emerald-200'
                    }`}
                  >
                    <div className="font-bold text-slate-900 text-lg">{barber.name}</div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* STEP 4: TIME */}
          {step === 4 && (
            <div className="animate-fade-in">
              <h3 className="text-lg font-bold text-slate-900 mb-4">Data e Hora</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                   <label className="block text-sm font-medium text-slate-700 mb-2">Selecione o Dia</label>
                   <input 
                     type="date" 
                     className="w-full p-3 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all"
                     onChange={(e) => setSelectedDate(e.target.value)}
                   />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Horários Disponíveis</label>
                  <div className="grid grid-cols-3 gap-3">
                    {selectedDate ? timeSlots.map((time) => (
                        <button
                            key={time}
                            onClick={() => setSelectedTime(time)}
                            className={`py-2 px-3 rounded-lg text-sm font-semibold border transition-all ${
                                selectedTime === time 
                                ? 'bg-emerald-600 text-white border-emerald-600 shadow-md'
                                : 'bg-white text-slate-600 border-slate-200 hover:border-emerald-400 hover:text-emerald-600'
                            }`}
                        >
                            {time}
                        </button>
                    )) : (
                        <div className="col-span-3 text-center text-slate-400 py-4 bg-slate-50 rounded-lg text-sm">
                            Selecione um dia primeiro
                        </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}

           {/* STEP 5: CONFIRM */}
           {step === 5 && (
            <div className="animate-fade-in max-w-lg mx-auto">
              <div className="bg-emerald-50 border border-emerald-100 rounded-xl p-6 mb-6 text-center">
                <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-4 text-emerald-600">
                    <IconCheck className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-bold text-emerald-900 mb-1">Quase lá!</h3>
                <p className="text-emerald-700 text-sm">Confira os detalhes antes de agendar.</p>
              </div>

              <div className="space-y-4 border border-slate-200 rounded-xl p-6 bg-slate-50/50">
                <div className="flex justify-between items-center py-2 border-b border-slate-200">
                    <span className="text-slate-500">Unidade</span>
                    <span className="font-semibold text-slate-900 text-right">{selectedUnit?.name}</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-slate-200">
                    <span className="text-slate-500">Serviço</span>
                    <span className="font-semibold text-slate-900 text-right">{selectedService?.name}</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-slate-200">
                    <span className="text-slate-500">Profissional</span>
                    <span className="font-semibold text-slate-900 text-right">{selectedBarber?.name}</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-slate-200">
                    <span className="text-slate-500">Data e Hora</span>
                    <span className="font-semibold text-slate-900 text-right">{selectedDate} às {selectedTime}</span>
                </div>
                <div className="flex justify-between items-center pt-2">
                    <span className="text-slate-900 font-bold text-lg">Total</span>
                    <span className="font-bold text-emerald-600 text-xl">R$ {selectedService?.price.toFixed(2)}</span>
                </div>
              </div>
            </div>
          )}
        </div>

        <div className="p-6 border-t border-slate-100 bg-slate-50 flex justify-between items-center">
            {step > 1 ? (
                <button 
                    onClick={handleBack}
                    className="px-6 py-2.5 rounded-xl font-semibold text-slate-600 hover:bg-slate-200 transition-colors"
                >
                    Voltar
                </button>
            ) : (
                <button 
                    onClick={onCancel}
                    className="px-6 py-2.5 rounded-xl font-semibold text-red-500 hover:bg-red-50 transition-colors"
                >
                    Cancelar
                </button>
            )}

            <button
                onClick={step === 5 ? onComplete : handleNext}
                disabled={
                    (step === 1 && !selectedUnit) ||
                    (step === 2 && !selectedService) ||
                    (step === 3 && !selectedBarber) ||
                    (step === 4 && (!selectedDate || !selectedTime))
                }
                className={`px-8 py-2.5 rounded-xl font-bold text-white shadow-lg shadow-emerald-600/20 flex items-center transition-all ${
                     (step === 1 && !selectedUnit) ||
                     (step === 2 && !selectedService) ||
                     (step === 3 && !selectedBarber) ||
                     (step === 4 && (!selectedDate || !selectedTime))
                     ? 'bg-slate-300 cursor-not-allowed shadow-none'
                     : 'bg-emerald-600 hover:bg-emerald-700 hover:shadow-emerald-600/40 active:transform active:scale-95'
                }`}
            >
                {step === 5 ? 'Confirmar Agendamento' : 'Próximo'}
                {step !== 5 && <IconChevronRight className="w-4 h-4 ml-2" />}
            </button>
        </div>
      </div>
    </div>
  );
};