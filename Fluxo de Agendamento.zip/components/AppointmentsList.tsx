import React, { useState } from 'react';
import { Appointment } from '../types';
import { IconCalendar, IconClock, IconScissors, IconMapPin } from './Icons';

interface AppointmentsListProps {
  appointments: Appointment[];
  onCancelAppointment: (id: string) => void;
}

export const AppointmentsList: React.FC<AppointmentsListProps> = ({ appointments, onCancelAppointment }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedAppointmentId, setSelectedAppointmentId] = useState<string | null>(null);

  const openCancelModal = (id: string) => {
    setSelectedAppointmentId(id);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setSelectedAppointmentId(null);
  };

  const handleConfirmCancel = () => {
    if (selectedAppointmentId) {
      onCancelAppointment(selectedAppointmentId);
      closeModal();
    }
  };

  return (
    <div className="animate-fade-in h-full flex flex-col relative">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-slate-900">Meus Agendamentos</h2>
        <div className="flex bg-white rounded-lg p-1 border border-slate-200">
            <button className="px-4 py-1.5 text-sm font-medium bg-slate-100 text-slate-900 rounded-md shadow-sm">Próximos</button>
            <button className="px-4 py-1.5 text-sm font-medium text-slate-500 hover:text-slate-900">Histórico</button>
        </div>
      </div>

      <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden flex-1">
        {appointments.length > 0 ? (
          <div className="divide-y divide-slate-100">
            {appointments.map((apt) => (
              <div key={apt.id} className="p-6 hover:bg-slate-50 transition-colors flex flex-col md:flex-row md:items-center justify-between group">
                <div className="flex items-start space-x-4 mb-4 md:mb-0">
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center text-xl font-bold flex-shrink-0 ${
                        apt.status === 'confirmed' ? 'bg-emerald-100 text-emerald-700' : 
                        apt.status === 'cancelled' ? 'bg-red-100 text-red-700' : 'bg-slate-100 text-slate-500'
                    }`}>
                        {apt.date.split('-')[2]}
                    </div>
                    <div>
                        <h4 className={`text-lg font-bold ${apt.status === 'cancelled' ? 'text-slate-400 line-through' : 'text-slate-900'}`}>{apt.service.name}</h4>
                        <div className="flex flex-col sm:flex-row sm:items-center text-sm text-slate-500 mt-1 gap-y-1 sm:gap-x-4">
                            <span className="flex items-center"><IconClock className="w-3.5 h-3.5 mr-1" /> {apt.time}</span>
                            <span className="flex items-center"><IconScissors className="w-3.5 h-3.5 mr-1" /> {apt.barber.name}</span>
                            <span className="flex items-center"><IconMapPin className="w-3.5 h-3.5 mr-1" /> {apt.unit.name}</span>
                        </div>
                    </div>
                </div>
                <div className="flex items-center space-x-3 self-end md:self-auto">
                    <span className={`px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider ${
                        apt.status === 'confirmed' ? 'bg-emerald-100 text-emerald-700' : 
                        apt.status === 'cancelled' ? 'bg-red-100 text-red-700' : 'bg-amber-100 text-amber-700'
                    }`}>
                        {apt.status === 'confirmed' ? 'Confirmado' : apt.status === 'cancelled' ? 'Cancelado' : 'Pendente'}
                    </span>
                    
                    {apt.status !== 'cancelled' && apt.status !== 'completed' && (
                        <button 
                            onClick={() => openCancelModal(apt.id)}
                            className="text-slate-400 hover:text-red-500 p-2 transition-colors text-sm font-medium"
                        >
                            Cancelar
                        </button>
                    )}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="p-12 text-center text-slate-400">
            <IconCalendar className="w-12 h-12 mx-auto mb-3 opacity-50" />
            <p>Nenhum histórico encontrado.</p>
          </div>
        )}
      </div>

      {/* Cancel Confirmation Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <div className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm transition-opacity" onClick={closeModal} />
            <div className="bg-white rounded-2xl shadow-xl w-full max-w-sm p-6 relative z-10 animate-fade-in-up">
                <h3 className="text-xl font-bold text-slate-900 mb-2">Cancelar agendamento?</h3>
                <p className="text-slate-500 text-sm mb-6">
                    Tem certeza que deseja cancelar? Essa ação não pode ser desfeita.
                </p>
                <div className="flex space-x-3">
                    <button 
                        onClick={closeModal}
                        className="flex-1 px-4 py-2.5 bg-slate-100 text-slate-700 font-semibold rounded-xl hover:bg-slate-200 transition-colors"
                    >
                        Voltar
                    </button>
                    <button 
                        onClick={handleConfirmCancel}
                        className="flex-1 px-4 py-2.5 bg-red-600 text-white font-semibold rounded-xl hover:bg-red-700 shadow-lg shadow-red-200 transition-colors"
                    >
                        Sim, cancelar
                    </button>
                </div>
            </div>
        </div>
      )}
    </div>
  );
};