import React, { useState } from 'react';
import { Appointment } from '../types';
import { IconCalendar, IconClock, IconMapPin, IconChart } from './Icons';

interface DashboardProps {
  appointments: Appointment[];
  onNewBooking: () => void;
  onCancelAppointment: (id: string) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ appointments, onNewBooking, onCancelAppointment }) => {
  const nextAppointment = appointments.find(a => a.status === 'confirmed');
  const [isModalOpen, setIsModalOpen] = useState(false);

  return (
    <div className="space-y-8 animate-fade-in relative">
      <header>
        <h2 className="text-3xl font-bold text-slate-900 tracking-tight">Olá, Roberto 👋</h2>
        <p className="text-slate-500 mt-2 text-lg">Aqui está o resumo dos seus agendamentos.</p>
      </header>

      {/* Metrics Row */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex items-center">
            <div className="w-12 h-12 rounded-xl bg-blue-50 flex items-center justify-center text-blue-600 mr-4">
                <IconCalendar className="w-6 h-6" />
            </div>
            <div>
                <p className="text-sm font-medium text-slate-500">Agendamentos Totais</p>
                <p className="text-2xl font-bold text-slate-900">12</p>
            </div>
        </div>
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex items-center">
             <div className="w-12 h-12 rounded-xl bg-purple-50 flex items-center justify-center text-purple-600 mr-4">
                <IconClock className="w-6 h-6" />
            </div>
            <div>
                <p className="text-sm font-medium text-slate-500">Próxima Visita</p>
                <p className="text-2xl font-bold text-slate-900">Hoje</p>
            </div>
        </div>
      </div>

      <section>
        <div className="flex items-center justify-between mb-4">
            <h3 className="text-xl font-bold text-slate-900">Próximo Agendamento</h3>
        </div>

        {nextAppointment ? (
            <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden relative group">
                <div className="absolute top-0 left-0 w-2 h-full bg-emerald-500" />
                <div className="p-6 md:flex items-center justify-between">
                    <div className="flex items-start md:items-center space-x-6">
                         <div className="flex flex-col items-center justify-center bg-slate-100 rounded-xl w-20 h-20 text-slate-900 flex-shrink-0">
                            <span className="text-xs font-bold uppercase text-slate-500">Nov</span>
                            <span className="text-3xl font-bold">14</span>
                         </div>
                         <div>
                            <h4 className="text-xl font-bold text-slate-900">{nextAppointment.service.name}</h4>
                            <p className="text-slate-500 mb-2">com {nextAppointment.barber.name}</p>
                            <div className="flex flex-wrap gap-3">
                                <span className="inline-flex items-center text-sm text-slate-600 bg-slate-50 px-3 py-1 rounded-full border border-slate-100">
                                    <IconClock className="w-4 h-4 mr-1.5" />
                                    {nextAppointment.time} ({nextAppointment.service.durationMin} min)
                                </span>
                                <span className="inline-flex items-center text-sm text-slate-600 bg-slate-50 px-3 py-1 rounded-full border border-slate-100">
                                    <IconMapPin className="w-4 h-4 mr-1.5" />
                                    {nextAppointment.unit.name}
                                </span>
                            </div>
                         </div>
                    </div>
                    <div className="mt-6 md:mt-0 flex flex-wrap gap-3">
                         <button 
                            onClick={() => setIsModalOpen(true)}
                            className="px-5 py-2.5 text-sm font-semibold text-red-600 bg-red-50 border border-transparent rounded-xl hover:bg-red-100 transition-colors"
                        >
                            Cancelar
                        </button>
                        <button className="px-5 py-2.5 text-sm font-semibold text-slate-600 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 hover:border-slate-300 transition-colors">
                            Reagendar
                        </button>
                        <button className="px-5 py-2.5 text-sm font-semibold text-white bg-emerald-600 rounded-xl hover:bg-emerald-700 shadow-lg shadow-emerald-200 transition-all">
                            Detalhes
                        </button>
                    </div>
                </div>
            </div>
        ) : (
            <div className="bg-white rounded-2xl border border-dashed border-slate-300 p-12 text-center">
                <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4 text-slate-400">
                    <IconCalendar className="w-8 h-8" />
                </div>
                <h4 className="text-lg font-bold text-slate-900 mb-2">Nenhum agendamento futuro</h4>
                <p className="text-slate-500 mb-6">Que tal dar um trato no visual hoje?</p>
                <button 
                    onClick={onNewBooking}
                    className="px-6 py-3 bg-slate-900 text-white font-bold rounded-xl hover:bg-slate-800 transition-all"
                >
                    Novo Agendamento
                </button>
            </div>
        )}
      </section>

      {/* Dashboard Local Modal */}
      {isModalOpen && nextAppointment && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <div className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm transition-opacity" onClick={() => setIsModalOpen(false)} />
            <div className="bg-white rounded-2xl shadow-xl w-full max-w-sm p-6 relative z-10 animate-fade-in-up">
                <h3 className="text-xl font-bold text-slate-900 mb-2">Cancelar agendamento?</h3>
                <p className="text-slate-500 text-sm mb-6">
                    Tem certeza que deseja cancelar o serviço <strong>{nextAppointment.service.name}</strong>?
                </p>
                <div className="flex space-x-3">
                    <button 
                        onClick={() => setIsModalOpen(false)}
                        className="flex-1 px-4 py-2.5 bg-slate-100 text-slate-700 font-semibold rounded-xl hover:bg-slate-200 transition-colors"
                    >
                        Voltar
                    </button>
                    <button 
                        onClick={() => {
                            onCancelAppointment(nextAppointment.id);
                            setIsModalOpen(false);
                        }}
                        className="flex-1 px-4 py-2.5 bg-red-600 text-white font-semibold rounded-xl hover:bg-red-700 shadow-lg shadow-red-200 transition-colors"
                    >
                        Sim, cancelar
                    </button>
                </div>
            </div>
        </div>
      )}
    </div>
  );
};