import React, { useState } from 'react';
import { Sidebar } from './components/Sidebar';
import { Dashboard } from './components/Dashboard';
import { BookingWizard } from './components/BookingWizard';
import { AppointmentsList } from './components/AppointmentsList';
import { ViewState } from './types';
import { MOCK_APPOINTMENTS } from './constants';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<ViewState>('dashboard');
  const [appointments, setAppointments] = useState(MOCK_APPOINTMENTS);

  const handleBookingComplete = () => {
    // In a real app, this would receive data and update backend
    alert("Agendamento realizado com sucesso! (Mock)");
    setCurrentView('dashboard');
  };

  const handleCancelAppointment = (id: string) => {
    // In a real app: PUT /agendamentos/{id}/cancel
    setAppointments((prev) =>
      prev.map((apt) =>
        apt.id === id ? { ...apt, status: 'cancelled' } : apt
      )
    );
  };

  const renderContent = () => {
    switch (currentView) {
      case 'dashboard':
        return (
          <Dashboard
            appointments={appointments}
            onNewBooking={() => setCurrentView('booking')}
            onCancelAppointment={handleCancelAppointment}
          />
        );
      case 'booking':
        return (
          <BookingWizard
            onComplete={handleBookingComplete}
            onCancel={() => setCurrentView('dashboard')}
          />
        );
      case 'appointments':
        return (
          <AppointmentsList
            appointments={appointments}
            onCancelAppointment={handleCancelAppointment}
          />
        );
      default:
        return (
          <Dashboard
            appointments={appointments}
            onNewBooking={() => setCurrentView('booking')}
            onCancelAppointment={handleCancelAppointment}
          />
        );
    }
  };

  return (
    <div className="flex h-screen bg-slate-50 font-sans text-slate-900 overflow-hidden">
      {/* Sidebar - Hidden on mobile by default in standard patterns, but here responsive styled within component */}
      <div className="hidden md:flex h-full">
        <Sidebar currentView={currentView} onChangeView={setCurrentView} />
      </div>

      {/* Mobile Header (Only visible on small screens) */}
      <div className="md:hidden fixed top-0 left-0 right-0 h-16 bg-white border-b border-slate-200 z-50 px-4 flex items-center justify-between">
         <span className="font-bold text-lg">BarberBook</span>
         <button className="p-2 bg-slate-100 rounded-md" onClick={() => {
             // Simple toggle for demo purposes could go here
             // For now, we focus on the desktop layout predominantly as requested "responsive structure"
         }}>Menu</button>
      </div>

      {/* Main Content Area */}
      <main className="flex-1 overflow-y-auto p-4 md:p-8 pt-20 md:pt-8 scroll-smooth">
        <div className="max-w-6xl mx-auto h-full">
          {renderContent()}
        </div>
      </main>

      {/* Mobile Bottom Nav (Optional, for better mobile UX) */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 flex justify-around p-3 z-50 safe-area-bottom">
         <button onClick={() => setCurrentView('dashboard')} className={`p-2 rounded-lg ${currentView === 'dashboard' ? 'text-emerald-600 bg-emerald-50' : 'text-slate-400'}`}>
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
         </button>
         <button onClick={() => setCurrentView('booking')} className={`p-2 rounded-lg ${currentView === 'booking' ? 'text-emerald-600 bg-emerald-50' : 'text-slate-400'}`}>
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" x2="12" y1="8" y2="16"/><line x1="8" x2="16" y1="12" y2="12"/></svg>
         </button>
         <button onClick={() => setCurrentView('appointments')} className={`p-2 rounded-lg ${currentView === 'appointments' ? 'text-emerald-600 bg-emerald-50' : 'text-slate-400'}`}>
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect width="18" height="18" x="3" y="4" rx="2" ry="2"/><line x1="16" x2="16" y1="2" y2="6"/><line x1="8" x2="8" y1="2" y2="6"/><line x1="3" x2="21" y1="10" y2="10"/></svg>
         </button>
      </div>
    </div>
  );
};

export default App;