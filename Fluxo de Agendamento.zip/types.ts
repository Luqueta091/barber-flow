export type ViewState = 'dashboard' | 'booking' | 'appointments' | 'metrics';

export interface Unit {
  id: string;
  name: string;
  address: string;
  image: string;
}

export interface Service {
  id: string;
  name: string;
  price: number;
  durationMin: number;
  description: string;
}

export interface Barber {
  id: string;
  name: string;
  specialty: string;
  avatar: string;
  rating: number;
}

export interface TimeSlot {
  time: string;
  available: boolean;
}

export interface Appointment {
  id: string;
  date: string; // ISO Date
  time: string;
  clientName: string;
  service: Service;
  barber: Barber;
  unit: Unit;
  status: 'confirmed' | 'pending' | 'completed' | 'cancelled';
}

export interface Metrics {
  totalRevenue: number;
  totalAppointments: number;
  activeClients: number;
  cancellationRate: number;
}