import { Barber, Service, Unit, Appointment } from './types';

export const UNITS: Unit[] = [
  { id: 'u1', name: 'Barbearia Downtown', address: 'Av. Paulista, 1000 - SP', image: 'https://picsum.photos/400/200?random=1' },
  { id: 'u2', name: 'Vila Madalena Club', address: 'Rua Fradique Coutinho, 500 - SP', image: 'https://picsum.photos/400/200?random=2' },
];

export const SERVICES: Service[] = [
  { id: 's1', name: 'Corte Clássico', price: 60, durationMin: 45, description: 'Corte tradicional com tesoura e máquina, acabamento na navalha.' },
  { id: 's2', name: 'Barba Terapia', price: 45, durationMin: 30, description: 'Toalha quente, massagem facial e hidratação.' },
  { id: 's3', name: 'Combo Completo', price: 95, durationMin: 75, description: 'Corte de cabelo e barba completa com tratamento VIP.' },
];

export const BARBERS: Barber[] = [
  { id: 'b1', name: 'Carlos "Navalha"', specialty: 'Degradê', rating: 4.9, avatar: 'https://picsum.photos/100/100?random=3' },
  { id: 'b2', name: 'André Silva', specialty: 'Barba Clássica', rating: 4.8, avatar: 'https://picsum.photos/100/100?random=4' },
  { id: 'b3', name: 'Mariana Costa', specialty: 'Cortes Modernos', rating: 5.0, avatar: 'https://picsum.photos/100/100?random=5' },
];

export const MOCK_APPOINTMENTS: Appointment[] = [
  {
    id: 'a1',
    date: new Date().toISOString().split('T')[0],
    time: '14:00',
    clientName: 'Roberto Almeida',
    service: SERVICES[2],
    barber: BARBERS[0],
    unit: UNITS[0],
    status: 'confirmed'
  },
  {
    id: 'a2',
    date: new Date(Date.now() + 86400000).toISOString().split('T')[0],
    time: '10:00',
    clientName: 'Roberto Almeida',
    service: SERVICES[0],
    barber: BARBERS[1],
    unit: UNITS[0],
    status: 'pending'
  }
];