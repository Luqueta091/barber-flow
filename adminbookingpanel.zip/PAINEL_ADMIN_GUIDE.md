# Guia de Integração do Painel Administrativo

## 1. Visão Geral
Este painel serve como o hub central para a gestão administrativa do sistema de agendamento. Seu objetivo principal é permitir o CRUD (Create, Read, Update, Delete) e a gestão de status das três entidades principais do negócio:
*   **Unidades:** Locais físicos de atendimento.
*   **Serviços:** Tipos de cortes ou tratamentos oferecidos.
*   **Barbeiros:** Profissionais que realizam os serviços.

## 2. Seções da UI

### Sidebar
Menu de navegação persistente (colapsável em mobile).
*   **Unidades:** Visualização de locais físicos.
*   **Serviços:** Catálogo de preços e durações.
*   **Barbeiros:** Gestão de equipe e alocação.
*   **Configurações:** (Placeholder) Ajustes globais do sistema.

### Header
Área superior fixa.
*   **Busca Global:** Input de texto para filtrar registros em qualquer tela.
*   **Botão "+ Novo":** Ação primária que abre um dropdown para criação rápida de qualquer entidade (Unidade, Serviço ou Barbeiro), abrindo o modal correspondente.

### Módulo de Unidades
*   **Visualização:** Cards em Grid.
*   **Dados:** Nome, Endereço, Horário de Funcionamento, Capacidade/hora.
*   **Ações:** Editar, Alternar Status (Ativo/Inativo).

### Módulo de Serviços
*   **Visualização:** Tabela (Table).
*   **Dados:** Nome, Duração (min), Preço, Unidades vinculadas.
*   **Ações:** Editar, Duplicar, Remover.

### Módulo de Barbeiros
*   **Visualização:** Cards com Avatar.
*   **Dados:** Foto/Avatar, Nome, Contato, Unidades de atuação.
*   **Ações:** Editar, Reatribuir Unidades (vincular a locais), Alternar Status.

---

## 3. Atributos para Integração (Seletores e Hooks)

Utilize estes seletores para vincular o JavaScript de lógica aos elementos da interface.

### Formulários (IDs de Input)
Os modais utilizam IDs únicos para facilitar a captura de dados via `document.getElementById` ou `FormData`.

| Entidade | Campo | ID do Input | Tipo |
| :--- | :--- | :--- | :--- |
| **Unidade** | Nome | `unit-name` | Text |
| | Endereço | `unit-address` | Text |
| | Abertura | `unit-open` | Time |
| | Fechamento | `unit-close` | Time |
| | Capacidade | `unit-capacity` | Number |
| **Serviço** | Nome | `service-name` | Text |
| | Duração | `service-duration` | Number (min) |
| | Preço | `service-price` | Number (decimal) |
| | Unidades | `service-units` | Checkbox (name group) |
| **Barbeiro** | Nome | `barber-name` | Text |
| | Contato | `barber-contact` | Tel |
| | Unidades | `barber-units` | Checkbox (name group) |

### Data Attributes (Ações e Identificação)
Utilize `dataset` para identificar qual registro está sendo manipulado e qual a intenção do usuário.

**Escopo do Container (Linha ou Card):**
*   `data-unit-id="{uuid}"`
*   `data-service-id="{uuid}"`
*   `data-barber-id="{uuid}"`

**Botões de Ação (`data-action`):**
Adicione *Event Listeners* globais ou delegados procurando por estes valores:

*   **Unidades:**
    *   `edit-unit`: Abrir modal preenchido.
    *   `toggle-unit`: Ativar/desativar logicamente.
    *   `create-unit`: Submeter formulário de nova unidade.
*   **Serviços:**
    *   `edit-service`: Abrir modal preenchido.
    *   `delete-service`: Confirmação de exclusão.
    *   `create-service`: Submeter formulário.
    *   `duplicate-service`: Criar cópia pré-preenchida.
*   **Barbeiros:**
    *   `edit-barber`: Abrir modal de edição cadastral.
    *   `toggle-barber`: Ativar/desativar acesso.
    *   `assign-units`: Abrir modal específico para vínculo de locais.
    *   `create-barber`: Submeter cadastro.

---

## 4. Fluxos Esperados

### Gestão de Unidades
1.  **Criar:** Usuário clica em "+ Novo" > "Unidade". Preenche nome, endereço, horários e capacidade. Clica em "Salvar". O sistema deve validar campos obrigatórios e atualizar a grid.
2.  **Editar:** Usuário clica em "Editar" no card. Modal abre com dados atuais (`value`). Ao salvar, envia PATCH/PUT.
3.  **Status:** Clique no ícone de Toggle. Atualização otimista (muda UI imediatamente, reverte se API falhar).

### Gestão de Serviços
1.  **Criar:** Define preço e duração. Deve selecionar pelo menos uma unidade onde o serviço é prestado (checkboxes carregados dinamicamente baseados nas unidades existentes).
2.  **Remover:** Ação destrutiva. Recomenda-se um `window.confirm` ou modal de confirmação antes do DELETE.

### Gestão de Barbeiros
1.  **Cadastro:** Nome e WhatsApp são essenciais.
2.  **Vínculo:** Um barbeiro pode atender em múltiplas unidades. O vínculo cruza a disponibilidade do profissional com o horário da unidade.

---

## 5. Endpoints de Referência (Sugestão API)

Estrutura sugerida para o backend RESTful.

**Unidades (`/api/units`)**
*   `GET /`: Listar todas (com paginação opcional).
*   `POST /`: Criar nova. Payload: `{ name, address, openTime, closeTime, capacity }`.
*   `PUT /:id`: Atualizar dados.
*   `PATCH /:id/toggle`: Alternar `isActive`.

**Serviços (`/api/services`)**
*   `GET /`: Listar todos.
*   `POST /`: Criar. Payload: `{ name, duration, price, unitIds[] }`.
*   `DELETE /:id`: Remover lógico ou físico.

**Barbeiros (`/api/barbers`)**
*   `GET /`: Listar equipe.
*   `POST /`: Cadastrar.
*   `PUT /:id/units`: Atualizar vínculos. Payload: `{ unitIds[] }`.

---

## 6. Estados de Interface

*   **Loading:** Exibir esqueleto (skeleton screens) ou spinner durante o `fetch` inicial.
*   **Vazio (Empty State):** Já implementado visualmente. Disparado quando o array de dados tem tamanho 0. Deve sempre oferecer o botão de criação ("CTA - Call to Action").
*   **Erro:** Exibir toasts ou alertas flutuantes caso uma requisição falhe.

---

## 7. Design Tokens (Resumo)

A interface utiliza **Tailwind CSS** com as seguintes definições base:

*   **Tipografia:** "Space Grotesk" (Google Fonts).
*   **Cores Primárias:**
    *   Fundo: `bg-slate-50`
    *   Texto Principal: `text-slate-800` / `text-slate-900`
    *   Ações/Links: `text-slate-600` hover `text-slate-900`
    *   Sidebar: `bg-white` com borda `border-slate-200`
    *   Status Ativo: `text-emerald-600`, `bg-emerald-50`
*   **Componentes:**
    *   Cards com `rounded-xl`, `border`, `shadow-sm`.
    *   Inputs com `focus:ring-2`, `focus:ring-emerald-500`.

---


