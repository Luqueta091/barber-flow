export interface Unit {
  id: string;
  name: string;
  address: string;
  openTime: string;
  closeTime: string;
  capacity: number;
  isActive: boolean;
}

export interface Service {
  id: string;
  name: string;
  duration: number; // minutes
  price: number;
  unitIds: string[];
}

export interface Barber {
  id: string;
  name: string;
  contact: string;
  unitIds: string[];
  isActive: boolean;
  avatarUrl?: string;
}

export type ViewState = 'units' | 'services' | 'barbers' | 'configs';
export type ModalType = 'unit' | 'service' | 'barber' | null;