import React, { useState } from 'react';
import { 
  LayoutDashboard, 
  Scissors, 
  Users, 
  Settings, 
  Menu, 
  Search, 
  Plus, 
  Store,
  MapPin,
  Clock,
  Edit2,
  Trash2,
  Copy,
  ToggleLeft,
  ToggleRight,
  Phone,
  Briefcase
} from 'lucide-react';
import { Unit, Service, Barber, ViewState, ModalType } from './types';
import { Modal } from './components/Modal';
import { EmptyState } from './components/EmptyState';

// --- MOCK DATA ---
const MOCK_UNITS: Unit[] = [
  { id: 'u1', name: 'Matriz Centro', address: 'Av. Paulista, 1000', openTime: '09:00', closeTime: '20:00', capacity: 4, isActive: true },
  { id: 'u2', name: 'Unidade Jardins', address: 'Rua Oscar Freire, 500', openTime: '10:00', closeTime: '22:00', capacity: 3, isActive: true },
];

const MOCK_SERVICES: Service[] = [
  { id: 's1', name: 'Corte Clássico', duration: 45, price: 60, unitIds: ['u1', 'u2'] },
  { id: 's2', name: 'Barba Terapia', duration: 30, price: 45, unitIds: ['u1'] },
];

const MOCK_BARBERS: Barber[] = [
  { id: 'b1', name: 'Carlos Silva', contact: '(11) 99999-1111', unitIds: ['u1'], isActive: true },
  { id: 'b2', name: 'Ana Souza', contact: '(11) 98888-2222', unitIds: ['u1', 'u2'], isActive: true },
  { id: 'b3', name: 'Roberto Firmino', contact: '(11) 97777-3333', unitIds: ['u2'], isActive: false },
];

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<ViewState>('units');
  const [isSidebarOpen, setSidebarOpen] = useState(false);
  const [activeModal, setActiveModal] = useState<ModalType>(null);
  const [showNewDropdown, setShowNewDropdown] = useState(false);

  // Mocks state to simulate reactivity (purely for demo, data attributes are the focus)
  const [units] = useState<Unit[]>(MOCK_UNITS);
  const [services] = useState<Service[]>(MOCK_SERVICES);
  const [barbers] = useState<Barber[]>(MOCK_BARBERS);

  const toggleSidebar = () => setSidebarOpen(!isSidebarOpen);

  // --- RENDER HELPERS ---

  const renderUnits = () => {
    if (units.length === 0) {
      return (
        <EmptyState 
          title="Nenhuma unidade cadastrada" 
          description="Comece adicionando sua primeira unidade física para gerenciar atendimentos."
          actionLabel="+ Criar Unidade"
          onAction={() => setActiveModal('unit')}
        />
      );
    }

    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* <!-- Unidades --> */}
        {units.map((unit) => (
          <div 
            key={unit.id} 
            className="bg-white rounded-xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow overflow-hidden group"
            data-unit-id={unit.id}
          >
            <div className="p-5">
              <div className="flex justify-between items-start mb-4">
                <div className="flex items-center space-x-3">
                  <div className="bg-emerald-100 p-2 rounded-lg">
                    <Store className="text-emerald-600" size={20} />
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-800">{unit.name}</h3>
                    <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${unit.isActive ? 'bg-emerald-50 text-emerald-700' : 'bg-slate-100 text-slate-500'}`}>
                      {unit.isActive ? 'Ativa' : 'Inativa'}
                    </span>
                  </div>
                </div>
              </div>
              
              <div className="space-y-2 text-sm text-slate-600 mb-6">
                <div className="flex items-center gap-2">
                  <MapPin size={16} className="text-slate-400" />
                  <span>{unit.address}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock size={16} className="text-slate-400" />
                  <span>{unit.openTime} - {unit.closeTime}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Users size={16} className="text-slate-400" />
                  <span>Capacidade: {unit.capacity}/h</span>
                </div>
              </div>

              <div className="flex gap-2 pt-4 border-t border-slate-100">
                <button 
                  className="flex-1 flex items-center justify-center gap-2 px-3 py-2 text-sm font-medium text-slate-700 bg-slate-50 hover:bg-slate-100 rounded-lg transition-colors"
                  data-action="edit-unit"
                  data-unit-id={unit.id}
                >
                  <Edit2 size={14} /> Editar
                </button>
                <button 
                  className={`px-3 py-2 rounded-lg transition-colors ${unit.isActive ? 'text-emerald-600 hover:bg-emerald-50' : 'text-slate-400 hover:bg-slate-100'}`}
                  data-action="toggle-unit"
                  data-unit-id={unit.id}
                  title={unit.isActive ? 'Desativar' : 'Ativar'}
                >
                  {unit.isActive ? <ToggleRight size={24} /> : <ToggleLeft size={24} />}
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  };

  const renderServices = () => {
    if (services.length === 0) {
      return (
         <EmptyState 
          title="Nenhum serviço disponível" 
          description="Cadastre os serviços que sua barbearia oferece aos clientes."
          actionLabel="+ Criar Serviço"
          onAction={() => setActiveModal('service')}
        />
      );
    }

    return (
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        {/* <!-- Serviços --> */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm text-slate-600">
            <thead className="bg-slate-50 border-b border-slate-200">
              <tr>
                <th className="px-6 py-4 font-semibold text-slate-800">Nome do Serviço</th>
                <th className="px-6 py-4 font-semibold text-slate-800">Duração</th>
                <th className="px-6 py-4 font-semibold text-slate-800">Preço</th>
                <th className="px-6 py-4 font-semibold text-slate-800">Unidades</th>
                <th className="px-6 py-4 font-semibold text-slate-800 text-right">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {services.map((service) => (
                <tr key={service.id} className="hover:bg-slate-50/50 transition-colors" data-service-id={service.id}>
                  <td className="px-6 py-4 font-medium text-slate-800">{service.name}</td>
                  <td className="px-6 py-4">{service.duration} min</td>
                  <td className="px-6 py-4 font-mono text-slate-700">R$ {service.price.toFixed(2)}</td>
                  <td className="px-6 py-4">
                    <div className="flex flex-wrap gap-1">
                      {service.unitIds.map(uid => {
                        const u = units.find(u => u.id === uid);
                        return u ? (
                          <span key={uid} className="inline-flex px-2 py-0.5 text-xs rounded bg-slate-100 text-slate-600 border border-slate-200">
                            {u.name}
                          </span>
                        ) : null;
                      })}
                    </div>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex justify-end gap-2">
                      <button className="p-1.5 text-slate-500 hover:text-emerald-600 hover:bg-emerald-50 rounded transition-colors" data-action="edit-service" title="Editar">
                        <Edit2 size={16} />
                      </button>
                      <button className="p-1.5 text-slate-500 hover:text-blue-600 hover:bg-blue-50 rounded transition-colors" data-action="duplicate-service" title="Duplicar">
                        <Copy size={16} />
                      </button>
                      <button className="p-1.5 text-slate-500 hover:text-red-600 hover:bg-red-50 rounded transition-colors" data-action="delete-service" title="Remover">
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  };

  const renderBarbers = () => {
    if (barbers.length === 0) {
      return (
         <EmptyState 
          title="Nenhum profissional" 
          description="Adicione barbeiros e vincule-os às unidades de atendimento."
          actionLabel="+ Adicionar Barbeiro"
          onAction={() => setActiveModal('barber')}
        />
      );
    }

    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {/* <!-- Barbeiros --> */}
        {barbers.map((barber) => (
          <div 
            key={barber.id} 
            className={`bg-white rounded-xl border shadow-sm transition-all hover:-translate-y-1 ${barber.isActive ? 'border-slate-200' : 'border-slate-200 opacity-75 grayscale'}`}
            data-barber-id={barber.id}
          >
            <div className="p-6 flex flex-col items-center text-center">
              <div className="w-20 h-20 rounded-full bg-gradient-to-br from-slate-200 to-slate-300 mb-4 flex items-center justify-center text-slate-500 font-bold text-xl overflow-hidden shadow-inner">
                {barber.avatarUrl ? (
                  <img src={barber.avatarUrl} alt={barber.name} className="w-full h-full object-cover" />
                ) : (
                  barber.name.substring(0, 2).toUpperCase()
                )}
              </div>
              <h3 className="font-bold text-lg text-slate-800 mb-1">{barber.name}</h3>
              <div className="flex items-center gap-1.5 text-sm text-slate-500 mb-4">
                <Phone size={14} /> {barber.contact}
              </div>

              <div className="w-full border-t border-slate-100 pt-4 mb-4">
                <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Unidades</p>
                <div className="flex flex-wrap justify-center gap-1">
                   {barber.unitIds.map(uid => {
                        const u = units.find(u => u.id === uid);
                        return u ? (
                          <span key={uid} className="inline-flex px-2 py-0.5 text-xs rounded-full bg-slate-100 text-slate-600">
                            {u.name}
                          </span>
                        ) : null;
                      })}
                </div>
              </div>

              <div className="w-full flex gap-2">
                <button 
                  className="flex-1 py-2 text-sm font-medium text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors shadow-sm"
                  data-action="edit-barber"
                >
                  Editar
                </button>
                <button 
                  className="px-3 py-2 text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
                  data-action="assign-units"
                  title="Reatribuir Unidades"
                >
                  <Briefcase size={18} />
                </button>
                 <button 
                  className={`px-3 py-2 rounded-lg transition-colors ${barber.isActive ? 'text-emerald-600 bg-emerald-50 hover:bg-emerald-100' : 'text-slate-400 bg-slate-100'}`}
                  data-action="toggle-barber"
                  title={barber.isActive ? "Ativo" : "Inativo"}
                >
                  {barber.isActive ? <ToggleRight size={18} /> : <ToggleLeft size={18} />}
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  };

  return (
    <div className="flex h-screen bg-slate-50 text-slate-900 font-sans">
      
      {/* SIDEBAR */}
      <aside 
        className={`fixed inset-y-0 left-0 z-40 w-64 bg-white border-r border-slate-200 transform transition-transform duration-300 ease-in-out md:translate-x-0 md:static ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}
      >
        <div className="h-full flex flex-col">
          <div className="h-16 flex items-center px-6 border-b border-slate-100">
            <span className="text-xl font-bold tracking-tight bg-gradient-to-r from-slate-800 to-slate-600 bg-clip-text text-transparent">
              BarberAdmin
            </span>
          </div>
          
          <nav className="flex-1 px-3 py-6 space-y-1">
            <button 
              onClick={() => { setCurrentView('units'); setSidebarOpen(false); }}
              className={`flex items-center w-full px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${currentView === 'units' ? 'bg-slate-100 text-slate-900' : 'text-slate-500 hover:text-slate-900 hover:bg-slate-50'}`}
            >
              <Store className="mr-3 h-5 w-5" /> Unidades
            </button>
            <button 
              onClick={() => { setCurrentView('services'); setSidebarOpen(false); }}
              className={`flex items-center w-full px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${currentView === 'services' ? 'bg-slate-100 text-slate-900' : 'text-slate-500 hover:text-slate-900 hover:bg-slate-50'}`}
            >
              <Scissors className="mr-3 h-5 w-5" /> Serviços
            </button>
            <button 
              onClick={() => { setCurrentView('barbers'); setSidebarOpen(false); }}
              className={`flex items-center w-full px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${currentView === 'barbers' ? 'bg-slate-100 text-slate-900' : 'text-slate-500 hover:text-slate-900 hover:bg-slate-50'}`}
            >
              <Users className="mr-3 h-5 w-5" /> Barbeiros
            </button>
            <div className="pt-4 mt-4 border-t border-slate-100">
              <button 
                onClick={() => { setCurrentView('configs'); setSidebarOpen(false); }}
                className={`flex items-center w-full px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${currentView === 'configs' ? 'bg-slate-100 text-slate-900' : 'text-slate-500 hover:text-slate-900 hover:bg-slate-50'}`}
              >
                <Settings className="mr-3 h-5 w-5" /> Configurações
              </button>
            </div>
          </nav>

          <div className="p-4 border-t border-slate-100">
            <div className="flex items-center gap-3">
              <div className="h-8 w-8 rounded-full bg-slate-200 flex items-center justify-center font-bold text-xs text-slate-600">AD</div>
              <div>
                <p className="text-sm font-medium text-slate-900">Admin</p>
                <p className="text-xs text-slate-500">admin@barber.com</p>
              </div>
            </div>
          </div>
        </div>
      </aside>

      {/* MAIN CONTENT WRAPPER */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        
        {/* HEADER */}
        <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-4 md:px-8 z-30 sticky top-0">
          <div className="flex items-center gap-4">
            <button onClick={toggleSidebar} className="md:hidden p-2 text-slate-500 hover:bg-slate-100 rounded-lg">
              <Menu size={24} />
            </button>
            <h1 className="text-xl font-bold text-slate-800 hidden sm:block">
              {currentView === 'units' && 'Gerenciar Unidades'}
              {currentView === 'services' && 'Catálogo de Serviços'}
              {currentView === 'barbers' && 'Equipe de Barbeiros'}
              {currentView === 'configs' && 'Configurações'}
            </h1>
          </div>

          <div className="flex items-center gap-4">
            <div className="hidden md:flex items-center relative">
              <Search className="absolute left-3 text-slate-400 h-4 w-4" />
              <input 
                type="text" 
                placeholder="Buscar..." 
                className="pl-9 pr-4 py-2 w-64 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-slate-200 focus:bg-white transition-all"
              />
            </div>

            <div className="relative">
              <button 
                onClick={() => setShowNewDropdown(!showNewDropdown)}
                className="flex items-center gap-2 bg-slate-900 hover:bg-slate-800 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-slate-900"
              >
                <Plus size={16} /> 
                <span className="hidden sm:inline">Novo</span>
              </button>

              {/* DROPDOWN */}
              {showNewDropdown && (
                <>
                  <div className="fixed inset-0 z-10" onClick={() => setShowNewDropdown(false)}></div>
                  <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-xl border border-slate-100 py-1 z-20 animate-in fade-in slide-in-from-top-2 duration-200">
                    <button onClick={() => { setActiveModal('unit'); setShowNewDropdown(false); }} className="w-full text-left px-4 py-2 text-sm text-slate-700 hover:bg-slate-50 flex items-center gap-2">
                      <Store size={14} /> Unidade
                    </button>
                    <button onClick={() => { setActiveModal('service'); setShowNewDropdown(false); }} className="w-full text-left px-4 py-2 text-sm text-slate-700 hover:bg-slate-50 flex items-center gap-2">
                      <Scissors size={14} /> Serviço
                    </button>
                    <button onClick={() => { setActiveModal('barber'); setShowNewDropdown(false); }} className="w-full text-left px-4 py-2 text-sm text-slate-700 hover:bg-slate-50 flex items-center gap-2">
                      <Users size={14} /> Barbeiro
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>
        </header>

        {/* MAIN SCROLL AREA */}
        <main className="flex-1 overflow-auto bg-slate-50/50 p-4 md:p-8">
          <div className="max-w-7xl mx-auto">
             {currentView === 'units' && renderUnits()}
             {currentView === 'services' && renderServices()}
             {currentView === 'barbers' && renderBarbers()}
             {currentView === 'configs' && (
               <div className="p-12 text-center text-slate-400 border-2 border-dashed border-slate-200 rounded-xl">
                 Configurações do sistema (Placeholder)
               </div>
             )}
          </div>
        </main>
      </div>

      {/* --- MODALS --- */}

      {/* MODAL: UNIDADE */}
      <Modal 
        isOpen={activeModal === 'unit'} 
        onClose={() => setActiveModal(null)} 
        title="Nova Unidade"
      >
        <form className="space-y-4" onSubmit={(e) => e.preventDefault()}>
          <div>
            <label htmlFor="unit-name" className="block text-sm font-medium text-slate-700 mb-1">Nome da Unidade</label>
            <input type="text" id="unit-name" name="unit-name" className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all" placeholder="Ex: Matriz Centro" />
          </div>
          <div>
            <label htmlFor="unit-address" className="block text-sm font-medium text-slate-700 mb-1">Endereço Completo</label>
            <input type="text" id="unit-address" name="unit-address" className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all" placeholder="Rua, Número, Bairro" />
          </div>
          <div className="grid grid-cols-2 gap-4">
             <div>
              <label htmlFor="unit-open" className="block text-sm font-medium text-slate-700 mb-1">Abertura</label>
              <input type="time" id="unit-open" name="unit-open" className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all" />
            </div>
            <div>
              <label htmlFor="unit-close" className="block text-sm font-medium text-slate-700 mb-1">Fechamento</label>
              <input type="time" id="unit-close" name="unit-close" className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all" />
            </div>
          </div>
          <div>
            <label htmlFor="unit-capacity" className="block text-sm font-medium text-slate-700 mb-1">Capacidade (atendimentos/hora)</label>
            <input type="number" id="unit-capacity" name="unit-capacity" min="1" className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all" placeholder="4" />
          </div>
          <div className="pt-4 flex justify-end gap-3">
             <button type="button" onClick={() => setActiveModal(null)} className="px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-100 rounded-lg transition-colors">Cancelar</button>
             <button type="submit" className="px-4 py-2 text-sm font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors" data-action="create-unit">Salvar Unidade</button>
          </div>
        </form>
      </Modal>

      {/* MODAL: SERVIÇO */}
      <Modal 
        isOpen={activeModal === 'service'} 
        onClose={() => setActiveModal(null)} 
        title="Novo Serviço"
      >
        <form className="space-y-4" onSubmit={(e) => e.preventDefault()}>
          <div>
            <label htmlFor="service-name" className="block text-sm font-medium text-slate-700 mb-1">Nome do Serviço</label>
            <input type="text" id="service-name" name="service-name" className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all" placeholder="Ex: Corte Degrade" />
          </div>
          <div className="grid grid-cols-2 gap-4">
             <div>
              <label htmlFor="service-duration" className="block text-sm font-medium text-slate-700 mb-1">Duração (min)</label>
              <input type="number" id="service-duration" name="service-duration" className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all" placeholder="45" />
            </div>
            <div>
              <label htmlFor="service-price" className="block text-sm font-medium text-slate-700 mb-1">Preço (R$)</label>
              <input type="number" step="0.01" id="service-price" name="service-price" className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all" placeholder="0.00" />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Unidades Disponíveis</label>
            <div className="space-y-2 max-h-32 overflow-y-auto p-2 border border-slate-100 rounded-lg bg-slate-50">
              {units.map(u => (
                <label key={u.id} className="flex items-center gap-2 cursor-pointer">
                  <input type="checkbox" name="service-units" value={u.id} className="rounded text-emerald-600 focus:ring-emerald-500 border-slate-300" />
                  <span className="text-sm text-slate-600">{u.name}</span>
                </label>
              ))}
            </div>
          </div>
          <div className="pt-4 flex justify-end gap-3">
             <button type="button" onClick={() => setActiveModal(null)} className="px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-100 rounded-lg transition-colors">Cancelar</button>
             <button type="submit" className="px-4 py-2 text-sm font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors" data-action="create-service">Salvar Serviço</button>
          </div>
        </form>
      </Modal>

      {/* MODAL: BARBEIRO */}
      <Modal 
        isOpen={activeModal === 'barber'} 
        onClose={() => setActiveModal(null)} 
        title="Novo Barbeiro"
      >
        <form className="space-y-4" onSubmit={(e) => e.preventDefault()}>
          <div>
            <label htmlFor="barber-name" className="block text-sm font-medium text-slate-700 mb-1">Nome Completo</label>
            <input type="text" id="barber-name" name="barber-name" className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all" placeholder="Ex: João Silva" />
          </div>
          <div>
            <label htmlFor="barber-contact" className="block text-sm font-medium text-slate-700 mb-1">Contato (WhatsApp)</label>
            <input type="tel" id="barber-contact" name="barber-contact" className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all" placeholder="(00) 00000-0000" />
          </div>
           <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Vincular Unidades</label>
            <div className="space-y-2 max-h-32 overflow-y-auto p-2 border border-slate-100 rounded-lg bg-slate-50">
              {units.map(u => (
                <label key={u.id} className="flex items-center gap-2 cursor-pointer">
                  <input type="checkbox" name="barber-units" value={u.id} className="rounded text-emerald-600 focus:ring-emerald-500 border-slate-300" />
                  <span className="text-sm text-slate-600">{u.name}</span>
                </label>
              ))}
            </div>
          </div>
          <div className="pt-4 flex justify-end gap-3">
             <button type="button" onClick={() => setActiveModal(null)} className="px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-100 rounded-lg transition-colors">Cancelar</button>
             <button type="submit" className="px-4 py-2 text-sm font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors" data-action="create-barber">Cadastrar Barbeiro</button>
          </div>
        </form>
      </Modal>

    </div>
  );
};

export default App;