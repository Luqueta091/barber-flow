import React from 'react';
import { PackageOpen } from 'lucide-react';

interface EmptyStateProps {
  title: string;
  description: string;
  actionLabel: string;
  onAction: () => void;
}

export const EmptyState: React.FC<EmptyStateProps> = ({ title, description, actionLabel, onAction }) => {
  return (
    <div className="flex flex-col items-center justify-center py-12 px-4 border-2 border-dashed border-slate-200 rounded-xl bg-slate-50/50 text-center">
      <div className="bg-slate-100 p-4 rounded-full mb-4">
        <PackageOpen size={32} className="text-slate-400" />
      </div>
      <h3 className="text-lg font-medium text-slate-900 mb-1">{title}</h3>
      <p className="text-slate-500 max-w-xs mb-6 text-sm">{description}</p>
      <button
        onClick={onAction}
        className="px-4 py-2 bg-slate-800 text-white text-sm font-medium rounded-lg hover:bg-slate-700 transition-colors focus:ring-2 focus:ring-offset-2 focus:ring-slate-800"
      >
        {actionLabel}
      </button>
    </div>
  );
};