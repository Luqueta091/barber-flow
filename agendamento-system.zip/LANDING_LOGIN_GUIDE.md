# Guia de Implementação: Landing & Login
## Sistema de Agendamento

Este documento define a especificação técnica e visual para a integração da página de Landing e Login do sistema.

### 1. Visão Geral
O propósito desta página é garantir que qualquer usuário (Cliente ou Staff) possua uma sessão válida antes de acessar as funcionalidades de agendamento ou administração.
Existem dois fluxos distintos de autenticação:
1.  **Cliente:** Autenticação "passwordless" via OTP (One-Time Password) enviado por SMS/WhatsApp. Prioriza baixa fricção.
2.  **Staff/Admin:** Autenticação tradicional via Email e Senha.

---

### 2. Seções da Interface (UI)

#### A. Hero / Landing
*   **Objetivo:** Apresentação rápida do sistema e direcionamento para o login.
*   **Componentes:**
    *   Título e Subtítulo convidativos.
    *   **CTA Principal:** Botão "Entrar como cliente" (Rola a página ou foca no formulário).
    *   Link secundário/discreto para acesso administrativo (Staff).

#### B. Login Cliente (Fluxo OTP)
*   **Estado 1 (Identificação):**
    *   Campo para inserção do telefone.
    *   Botão para solicitar o código.
*   **Estado 2 (Validação):**
    *   Campo para inserção do código OTP (4 ou 6 dígitos).
    *   Botão para validar e entrar.
    *   Link "Reenviar código".

#### C. Login Staff/Admin
*   **Componentes:**
    *   Campo de Email Corporativo.
    *   Campo de Senha.
    *   Botão "Entrar Staff".

---

### 3. Atributos para Integração (DOM)

Utilize estes seletores para vincular a lógica JavaScript aos elementos visuais.

#### Inputs (Campos de Dados)
| Campo | ID / Name | Tipo | Descrição |
| :--- | :--- | :--- | :--- |
| **Telefone Cliente** | `client-phone` | `tel` | Formato (00) 00000-0000 |
| **Código OTP** | `client-otp` | `text/number` | Input numérico para o código recebido |
| **Email Staff** | `staff-email` | `email` | Email de acesso administrativo |
| **Senha Staff** | `staff-password` | `password` | Senha do colaborador |

#### Botões (Ações)
Utilize o atributo `data-action` para capturar os cliques.

| Botão | Atributo `data-action` | Comportamento Esperado |
| :--- | :--- | :--- |
| **Enviar Código** | `send-otp` | Dispara requisição de SMS para o telefone |
| **Validar OTP** | `validate-otp` | Envia o código digitado para verificação |
| **Login Staff** | `login-staff` | Submete credenciais (Email/Senha) |

---

### 4. Feedback Visual (Erros e Loading)

#### Injeção de Erros
*   **Localização:** Adicionar um elemento `<small>` ou `<span>` com a classe `text-red-500` imediatamente abaixo do input problemático.
*   **Mensagens Globais:** Para erros de servidor (ex: 500), exibir um "Toast" ou alerta no topo do formulário.

#### Estados de Carregamento (Spinners)
*   **Botões:** Ao clicar em qualquer botão de ação (`send-otp`, `validate-otp`, `login-staff`):
    1.  Adicionar atributo `disabled`.
    2.  Ocultar o texto do botão (ou torná-lo transparente).
    3.  Injetar um ícone SVG de spinner giratório centralizado no botão.
    4.  Restaurar o estado original após a resposta da API (sucesso ou erro).

---

### 5. Fluxos Lógicos Esperados

#### Fluxo Cliente (OTP)
1.  Usuário digita telefone em `#client-phone`.
2.  Clica em `[data-action="send-otp"]`.
3.  **UI:** Botão entra em loading. Input de telefone bloqueia.
4.  **Backend:** Envia SMS.
5.  **UI:** Transição para "Estado 2" (Exibe input `#client-otp`).
6.  Usuário digita código.
7.  Clica em `[data-action="validate-otp"]`.
8.  **Sucesso:** Redireciona para `/agendamento`.

#### Fluxo Staff
1.  Usuário preenche `#staff-email` e `#staff-password`.
2.  Clica em `[data-action="login-staff"]`.
3.  **UI:** Botão entra em loading.
4.  **Backend:** Valida hash da senha.
5.  **Sucesso:** Armazena token e redireciona para `/dashboard`.

---

### 6. Tratamento de Erros e Exceções

*   **OTP Inválido:** Manter o usuário no "Estado 2", limpar o campo `#client-otp`, exibir erro "Código incorreto" em vermelho e vibrar o input (animação CSS).
*   **OTP Expirado:** Exibir mensagem "Código expirou" e forçar retorno ao passo de envio de telefone.
*   **Credenciais Staff Inválidas:** Exibir "Email ou senha incorretos" sem especificar qual campo falhou (segurança).
*   **Erro de Rede:** Exibir "Sem conexão. Tente novamente."

---

### 7. Endpoints de Referência (API Mock)

Estrutura sugerida para as chamadas `fetch`:

*   **POST** `/auth/request-otp`
    *   Body: `{ "phone": "+55..." }`
*   **POST** `/auth/verify-otp`
    *   Body: `{ "phone": "+55...", "code": "123456" }`
*   **POST** `/auth/login-staff`
    *   Body: `{ "email": "...", "password": "..." }`

---

### 8. Mensagens de Estado (Copywriting)

| Contexto | Texto Sugerido |
| :--- | :--- |
| **Aguardando Código** | "Enviamos um código para seu WhatsApp/SMS." |
| **Erro Validação** | "Código inválido. Verifique e tente novamente." |
| **Sucesso** | "Autenticado com sucesso. Redirecionando..." |
| **Placeholder OTP** | "000000" |

---

### 9. Design Tokens & Estilo

*   **Tipografia:** `Space Grotesk` ou `Sora` (Google Fonts).
*   **Cores (Tailwind):**
    *   *Primary:* `emerald-500` / `emerald-600` (Ação principal, sucesso).
    *   *Neutral:* `slate-50` a `slate-900` (Textos, fundos, bordas).
    *   *Feedback:* `red-500` (Erro).
*   **Estilo Visual:**
    *   Bordas suaves (`rounded-lg` ou `rounded-xl`).
    *   Sombras difusas (`shadow-lg`, `shadow-slate-200/50`).
    *   Inputs grandes e clicáveis (Mobile-first).

---

### 10. Próximos Passos de Integração

1.  Criar arquivo `auth.js` e importar no final do `body`.
2.  Adicionar `addEventListener` para os botões baseados nos `data-action`.
3.  Implementar lógica de `toggle` para alternar entre login Cliente e Staff (esconder/mostrar containers).
4.  Configurar armazenamento do Token de Sessão (JWT) em `localStorage` ou `document.cookie` após sucesso.
5.  Implementar `window.location.href` para as rotas protegidas.
