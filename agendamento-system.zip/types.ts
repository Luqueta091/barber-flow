export enum UserRole {
  CLIENT = 'CLIENT',
  STAFF = 'STAFF'
}

export interface ClientLoginForm {
  name: string;
  phone: string;
}

export interface StaffLoginForm {
  email: string;
  password: string;
}